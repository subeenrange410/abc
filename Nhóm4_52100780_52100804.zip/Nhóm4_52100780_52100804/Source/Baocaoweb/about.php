<!DOCTYPE html>
<html>
<head>
    <title>Về chúng tôi</title>
    <link rel="stylesheet" href="css/about.css">
</head>
<body>
    <div class="container">
        <h1>ABOUT</h1>

        <div class="profile">
            <div class="1_profile"></div>
            <img src="./images/dat.jpg" alt="Avatar">
            <div>
                <h2>HO QUOC DAT</h2>
                <p>52100780</p>
            </div>
        </div>
        <div class="skills">
            <h3>Skills</h3>
            <ul>
                <li>HTML</li>
                <li>CSS</li>
                <li>JavaScript</li>
                <li>PHP</li>
                <li>MySQL</li>
                <li>RIOT</li>
            </ul>
        </div>
        <br>
        <div class="profile">
            <img src="./images/huyle.jpg" alt="Avatar">
            <div>
                <h2>LE NHAT HUY</h2>
                <p>52100804</p>
            </div>
        </div>
        <div class="skills">
            <h3>Skills</h3>
            <ul>
                <li>Adobe Photoshop</li>
                <li>Adobe Illustrator</li>
                <li>Adobe Lightroom</li>
                <li>Adobe Premiere</li>
                <li>Layout Design</li>
            </ul>
        </div>

    </div>
</body>
</html>

