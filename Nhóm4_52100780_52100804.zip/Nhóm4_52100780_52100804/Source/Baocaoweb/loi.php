<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 ERROR!!!</title>
    <link rel="stylesheet" type="text/css" href="css/styletonghop.css">
    <style>
            body {
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                background-color: #333;
                color: #fff;
                font-size: 2em;
            }

            .container {
                position: relative;
            }

            .container h1 {
                position: absolute;
                top: 50px;
                left: 50%;
                transform: translateX(-50%);
                font-size: 2em;
                text-align: center;
            }

            .container img {
                width: 80%;
                max-width: 500px;
                display: block;
                margin: 0 auto;
                filter: grayscale(100%);
                animation: zoom 5s infinite alternate;
            }

            @keyframes zoom {
                0% {
                    transform: scale(1);
                }
                50% {
                    transform: scale(1.2);
                }
                100% {
                    transform: scale(1);
                }
            }

            .container h1:hover {
                color: yellow;
            }



    </style>
    
</head>
<body>
    <h1>404 ERROR!!!</h1>
    <a href="admin.php" class="quayve" >Quay về trang chủ</a>
    
    <div class="container">
        <img src="./images/loi.jpg" alt="Error Image">
    </div>

</body>
</html>
