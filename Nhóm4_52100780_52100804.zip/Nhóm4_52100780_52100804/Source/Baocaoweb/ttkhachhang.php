<?php
    session_start();
    $makh = (int)$_SESSION['USERNAME_TK'];
    $phone = $_SESSION['SDT'];
    $gmail = $_SESSION['EMAIL'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông tin khách hàng</title>
</head>
<link rel="stylesheet" type="text/css" href="css/ttkhachhang.css">
<body>
<div>
        <?php
                 $host = 'localhost';
                 $dbName = 'batdong_san';
                 $username = 'root';
                 $password = '';
                 $conn = new mysqli($host, $username, $password, $dbName);
                 if ($conn->connect_error) {
                 die("Kết nối đến cơ sở dữ liệu thất bại: " . $conn->connect_error);
                 }

        
                    $sql = "SELECT * FROM thongtinkhachhang WHERE USERNAME_TK=$makh";
                    $result = $conn->query($sql);

                    // Hiển thị bảng dữ liệu trên trang web
                    echo "<table>";
                    echo "<tr><th>Email</th><th>SDT</th><th>Họ và tên</th><th>Giới tính</th><th>Ngày sinh</th><th>Địa chỉ</th><th>Nghề nghiệp</th><th>Tình trạng hôn nhân</th></tr>";
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $gmail . "</td>";
                        echo "<td>" . $phone . "</td>";
                        echo "<td>" . $row["hovaten_ttkh"] . "</td>";
                        echo "<td>" . $row["gioitinh"] . "</td>";
                        echo "<td>" . $row["ageborn"] . "</td>";
                        echo "<td>" . $row["diachi"] . "</td>";
                        echo "<td>" . $row["nghenghiep"] . "</td>";
                        echo "<td>" . $row["tinhtranghonnhan"] . "</td>";
    
                        echo "</tr>";
                    }
                    echo "</table>";

                    // Đóng kết nối đến cơ sở dữ liệu
                    $conn->close();
        ?>

                <form method="POST" action="thongtinkhachhang.php">
                <label for="hovaten">Họ và tên:</label>
                <input type="text" id="hovaten" name="hovaten"><br>

                <label for="gioitinh">Giới tính:</label>
                <select id="gioitinh" name="gioitinh">
                    <option value="Nam">Nam</option>
                    <option value="Nữ">Nữ</option>
                    <option value="Khác">Khác</option>
                </select><br>

                <label for="ageborn">Ngày sinh:</label>
                <input type="date" id="ageborn" name="ageborn"><br>

                <label for="diachi">Địa chỉ:</label>
                <input type="text" id="diachi" name="diachi"><br>

                <label for="nghenghiep">Nghề nghiệp:</label>
                <input type="text" id="nghenghiep" name="nghenghiep"><br>

                <label for="tinhtranghonnhan">Tình trạng hôn nhân:</label>
                <select id="tinhtranghonnhan" name="tinhtranghonnhan">
                    <option value="Độc thân">Độc thân</option>
                    <option value="Đã kết hôn">Đã kết hôn</option>
                </select><br>

                <input type="submit" value="Thay đổi">
                <button type="button" name="change_password" class="change_password" onclick="goToChangePassword()">Quay về</button>
                <script>
                    function goToChangePassword() {
                        window.location.href = "h.php";
                    }
                </script>
            </form>
    </div>
</body>
</html>