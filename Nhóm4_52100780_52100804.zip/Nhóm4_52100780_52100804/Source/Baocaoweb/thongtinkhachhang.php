<?php
    session_start();
    $makh = (int)$_SESSION['USERNAME_TK'];
    $phone = $_SESSION['SDT'];
    $gmail = $_SESSION['EMAIL'];




    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $hovaten = $_POST['hovaten'];
        $gioitinh = $_POST['gioitinh'];
        $ageborn = $_POST['ageborn'];
        $diachi = $_POST['diachi'];
        $nghenghiep = $_POST['nghenghiep'];
        $tinhtranghonnhan = $_POST['tinhtranghonnhan'];
    
        $host = 'localhost';
        $dbName = 'batdong_san';
        $username = 'root';
        $password = '';
        $conn = mysqli_connect($host, $username, $password, $dbName);
    
        if (!$conn) {
        die("Kết nối thất bại: " . mysqli_connect_error());
        }
    
        // Thêm thông tin khách hàng vào cơ sở dữ liệu
        $query = "UPDATE thongtinkhachhang SET hovaten_ttkh='$hovaten', gioitinh='$gioitinh', ageborn='$ageborn', diachi='$diachi', nghenghiep='$nghenghiep', tinhtranghonnhan='$tinhtranghonnhan' WHERE USERNAME_TK=$makh";
        $result = mysqli_query($conn, $query);
    
        if ($result) {
            echo "<script>alert('Cập nhật thông tin khách hàng thành công');</script>";
            echo "<script>window.location.href='ttkhachhang.php';</script>";
        } else {
            echo "<script>alert('Cập nhật thông tin khách hàng không thành công');</script>";
            
        }
    
        mysqli_close($conn);
    }
?>
