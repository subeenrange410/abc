<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chỉnh sửa thông tin</title>
    <style>
        /* Thiết lập màu nền cho trang web */
body {
    background-color: #f2f2f2;

}

/* Thiết lập khung cho biểu mẫu */
form {
    border: 1px solid #ccc;
    padding: 10px;
    margin: 10px auto;
    max-width: 500px;
    box-shadow: 0px 0px 20px rgba(21, 12, 12, 0.9);
}

/* Thiết lập kiểu dáng cho các nhãn */
label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;

}

/* Thiết lập kiểu dáng cho các ô nhập liệu */
input[type="text"], select {
    width: 100%;
    padding: 20px;
    
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-bottom: 10px;
}

/* Thiết lập kiểu dáng cho nút đăng ký */
input[type="submit"] {
    background-color:black;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
}

/* Thiết lập kiểu dáng cho nút quay lại */
a {
    background-color:azure;
    color: black;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: left;
    text-decoration: none;
}

/* Thiết lập kiểu dáng cho nút quay lại khi di chuột qua */
a:hover {
    background-color: #d32f2f;
}

input[type="submit"]:hover{
    background-color: grey;
}

    </style>
</head>
<body>
<?php
        $host = 'localhost';
        $dbName = 'batdong_san';
        $username = 'root';
        $password = '';

        // Kết nối đến cơ sở dữ liệu
        $conn = new mysqli($host, $username, $password, $dbName);
        if ($conn->connect_error) {
            die("Kết nối đến cơ sở dữ liệu thất bại: " . $conn->connect_error);
        }


        $id = $_GET['ID_ttkh'];
        $sql = "SELECT * FROM THONGTINKHACHHANG WHERE ID_ttkh='$id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
?>
    
<form method="POST" action="update_customer.php">
<label for="ID_ttkh">ID_ttkh:</label>
    <input type="text" id="ID_ttkh" name="ID_ttkh" value="<?php echo $row['ID_ttkh']; ?> " readonly><br>
    <label for="hovaten_ttkh">Họ và tên:</label>
    <input type="text" id="hovaten_ttkh" name="hovaten_ttkh" value="<?php echo $row['hovaten_ttkh']; ?>"><br>
    <label for="gioitinh">Giới tính:</label>
    <select id="gioitinh" name="gioitinh">
        <option value="Nam" <?php if ($row['gioitinh'] == 'Nam') echo 'selected="selected"'; ?>>Nam</option>
        <option value="Nữ" <?php if ($row['gioitinh'] == 'Nữ') echo 'selected="selected"'; ?>>Nữ</option>
        <option value="Khác" <?php if ($row['gioitinh'] == 'Khác') echo 'selected="selected"'; ?>>Khác</option>
    </select><br>

    <label for="ageborn">Ngày sinh:</label>
    <input type="text" id="ageborn" name="ageborn" value="<?php echo $row['ageborn']; ?>"><br>

    <label for="diachi">Địa chỉ:</label>
    <input type="text" id="diachi" name="diachi" value="<?php echo $row['diachi']; ?>"><br>

    <label for="nghenghiep">Nghề nghiệp:</label>
    <input type="text" id="nghenghiep" name="nghenghiep" value="<?php echo $row['nghenghiep']; ?>"><br>

    <label for="tinhtranghonnhan">Tình trạng hôn nhân:</label>
    <select id="tinhtranghonnhan" name="tinhtranghonnhan">
        <option value="Độc thân" <?php if ($row['tinhtranghonnhan'] == 'Độc thân') echo 'selected="selected"'; ?>>Độc thân</option>
        <option value="Đã kết hôn" <?php if ($row['tinhtranghonnhan'] == 'Đã kết hôn') echo 'selected="selected"'; ?>>Đã kết hôn</option>
    </select><br>

    <input type="submit" value="Cập nhật">
    <a href="admin.php">Quay lại trang admin</a>

</form>
    <?php
        } else {
                echo "Không tìm thấy bất động sản có ID là $id";
        }
        // Đóng kết nối đến cơ sở dữ liệu
        $conn->close();
    ?>

</body>
</html>