<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quên mật khẩu</title>
    <style>
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {  
            font-family: Arial, sans-serif;
            background-color:cornflowerblue;
            background-repeat: no-repeat;
            background-size: cover;
 
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 50px;
            color: #333;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 40px rgba(20, 10, 130, 0.9);
            max-width: 500px;
            width: 100%;
            margin: 0 auto;
            color: #ccc;
        }

        label {
            margin-bottom: 10px;
            font-weight: bold;
            font-size: 16px;
        }

        input[type="email"],
        input[type="tel"],
        input[type="password"] {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 100%;
            max-width: 300px;
            margin-bottom: 20px;
            font-size: 16px;
            color: #555;
        }

        input[type="submit"] {
            padding: 10px 20px;
            background-color: #4CAF50;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #f44336;
        }

        .login_dn {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #333;
            text-decoration: none;
            font-size: 14px;
        }

        .login_dn:hover {
            text-decoration: underline;
        }

        a {
                text-decoration: none; /* loại bỏ gạch chân mặc định trên liên kết */
                display: inline-block; /* hiển thị như một khối nhỏ */
                padding: 10px 20px; /* khoảng cách giữa nội dung và viền nút */
                background-color:darksalmon; /* màu nền của nút */
                color: white; /* màu chữ của nút */
                border-radius: 5px; /* bo tròn viền của nút */
                font-size: 16px; /* cỡ chữ của nút */
                transition: background-color 0.3s ease; /* hiệu ứng chuyển đổi màu nền khi di chuột vào */
        }

        a:hover {
        background-color:aliceblue /* màu nền mới khi di chuột vào */
        }


    </style>
</head>
<body>
<form method="post" action="ForgotPassword.php">
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required><br><br>
    <label for="phone">Số điện thoại:</label>
    <input type="tel" id="phone" name="phone" required><br><br>

    <input type="submit" name="submit" value="Kiểm tra">
    <a href="login.php" class="login_dn">Quay lại trang đăng nhập</a>
    </form>
<?php
    function hashPassword($password) {
        return sha1($password);
    }
    $host = 'localhost';
    $dbName = 'batdong_san';
    $username = 'root';
    $password = '';
    $conn = mysqli_connect($host, $username, $password, $dbName);
    if (!$conn) {
        die("Kết nối thất bại: " . mysqli_connect_error());
    }

    if(isset($_POST['submit'])) {
        $email = $_POST['email'];
        $sdt = $_POST['phone'];

        $sql = "SELECT * FROM taikhoan WHERE EMAIL='$email' AND SDT='$sdt'";
        $result = $conn->query($sql);

        if ($result->num_rows == 0) {
            echo "<script>alert('Email hoặc số điện thoại không tồn tại trong cơ sở dữ liệu');</script>";
        } else {
            echo "<form method='post' action='" . htmlspecialchars($_SERVER["PHP_SELF"]) . "'>";    
            echo "<label for='newPassword'>Mật khẩu mới:</label>";
            echo "<input type='password' id='newPassword' name='newPassword' required><br><br>";

            echo "<label for='confirmPassword'>Xác nhận mật khẩu mới:</label>";
            echo "<input type='password' id='confirmPassword' name='confirmPassword' required><br><br>";

            echo "<input type='hidden' id='email' name='email' value='" . $email . "'>";
            echo "<input type='submit' name='submit2' value='Lưu'>";
            echo "</form>";
        }
    }

    if(isset($_POST['submit2'])) {
        $email = $_POST['email'];
        $newPassword = $_POST['newPassword'];
        $confirmPassword = $_POST['confirmPassword'];
        $newPassword=hashPassword($newPassword);
        $confirmPassword=hashPassword($confirmPassword);
        if ($newPassword != $confirmPassword) {
            echo "<script>alert('Mật khẩu mới và xác nhận mật khẩu không khớp');</script>";
        } else {
            $updateSql = "UPDATE taikhoan SET PASS='$newPassword', PASS_CONFIRM='$confirmPassword' WHERE EMAIL='$email'";
            if ($conn->query($updateSql) === TRUE) {
                echo "<script>alert('Cập nhật mật khẩu thành công');</script>";
                echo "<script>window.location.href='login.php';</script>";
                exit();
            } else {
                echo "<script>alert('Lỗi khi cập nhật mật khẩu: " . $conn->error . "');</script>";
            }
        }
    }

    $conn->close();
?>

</body>
</html>