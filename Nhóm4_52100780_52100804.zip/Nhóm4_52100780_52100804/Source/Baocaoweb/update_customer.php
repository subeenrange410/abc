<?php
        $host = 'localhost';
        $dbName = 'batdong_san';
        $username = 'root';
        $password = '';

        // Kết nối đến cơ sở dữ liệu
        $conn = new mysqli($host, $username, $password, $dbName);
        if ($conn->connect_error) {
            die("Kết nối đến cơ sở dữ liệu thất bại: " . $conn->connect_error);
        }

        $id = $_POST['ID_ttkh'];
        $hovaten_ttkh = $_POST['hovaten_ttkh'];
        $gioitinh = $_POST['gioitinh'];
        $ageborn = $_POST['ageborn'];
        $diachi = $_POST['diachi'];
        $nghenghiep = $_POST['nghenghiep'];
        $tinhtranghonnhan = $_POST['tinhtranghonnhan'];

    
        // Cập nhật thông tin khách hàng vào bảng thongtinkhachhang
        $sql = "UPDATE thongtinkhachhang SET hovaten_ttkh='$hovaten_ttkh', gioitinh='$gioitinh', ageborn='$ageborn', diachi='$diachi', nghenghiep='$nghenghiep', tinhtranghonnhan='$tinhtranghonnhan' WHERE id_ttkh='$id'";
        if ($conn->query($sql) === TRUE) {
            echo "Cập nhật thông tin khách hàng thành công!";
            echo "<br>";
                echo "<a href='admin.php'>Quay lại trang admin</a>";
        } else {
            echo "Cập nhật thông tin khách hàng thất bại: " . $conn->error;
            echo "<script>window.location.href='loi.php';</script>";
        }
    
        // Đóng kết nối đến cơ sở dữ liệu
        $conn->close();
    ?>