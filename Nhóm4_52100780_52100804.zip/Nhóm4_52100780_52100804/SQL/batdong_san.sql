-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2023 at 06:02 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `batdong_san`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(50) NOT NULL,
  `email_admin` varchar(50) NOT NULL,
  `pass_admin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `email_admin`, `pass_admin`) VALUES
(1, 'hodatadmin@gmail.com', 'a6ee45faddb147e639bb45692e88d11382d552c7');

-- --------------------------------------------------------

--
-- Table structure for table `batdongsan`
--

CREATE TABLE `batdongsan` (
  `id` int(50) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `ward` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `ID_NDT` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batdongsan`
--

INSERT INTO `batdongsan` (`id`, `title`, `city`, `district`, `ward`, `price`, `image`, `type`, `note`, `ID_NDT`) VALUES
(1, 'Bất động sản 1', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Phường 7', '10 tỷ', './images/1.jpg', 'ban', '<h3>Thông tin mô tả:</h3>Chỉ 295.000đ++ cho mỗi mét vuông, giá siêu hấp dẫn cho dịp 30 tháng 04 nàyBonus thêm không gian sử dụng riêng đến 30m² mà không tính phí.Thoải mái sử dụng - rộng rãi thoáng mát cho đến 20 nhân sự!Văn phòng trung tâm, cách quận', 1),
(2, 'Bất động sản 2', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Phường 7', '12 tỷ', './images/2.jpg', 'thue', '<h3>Thông tin mô tả:</h3>Chỉ 295.000đ++ cho mỗi mét vuông, giá siêu hấp dẫn cho dịp 30 tháng 04 nàyBonus thêm không gian sử dụng riêng đến 30m² mà không tính phí.Thoải mái sử dụng - rộng rãi thoáng mát cho đến 20 nhân sự!Văn phòng trung tâm, cách qu', 2),
(3, 'Bất động sản 3', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Xã Bình Kiến', '10 tỷ', './images/3.jpg', 'thue', '<h3>Thông tin mô tả:</h3>BR - The Marq: Chính chủ.Bán 1PN - The Marq giá tốt hơn chủ đầu tư.Giá bán: 7.9 tỷ all in.Nhà mới, chưa ở.Giá hợp đồng: 8,7 tỷ.Xem nhà 24/24.Giá tốt để đầu tư The Marq.', 1),
(4, 'Bất động sản 4', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Phường 9', '9 tỷ', './images/4.jpg', 'ban', '<h3>Thông tin mô tả:</h3>Cần bán nhanh căn shophouse song lập 150m², trục đường Hải Âu 3 đối diện cụm phố nhật, giá cam kết rẻ nhất dự án Vinhomes Ocean Park, Gia Lâm.Diện tích. 150m².Xây dựng. 60m²/sàn(3,5 tầng).Mặt tiên. 8,3m.Sổ đỏ lâu dài.Gía ', 1),
(5, 'Bất động sản 5', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Phường 3', '3 tỷ', './images/5.jpg', 'thue', '<h3>Thông tin mô tả:</h3>Chuyên bán căn hộ Q7 Riverside 1PN 1.9 tỷ, 2PN 2.3 tỷ, 3PN 3.6 tỷ.* Căn 1PN - 1WC (53m²).- Gía chỉ 1,9 tỷ (1 căn duy nhất).- Giá từ 2 tỷ - 2,1 tỷ (tuỳ tầng và view).* Căn 2PN - 2WC (67m).- Gía chỉ 2,3 tỷ (1 căn duy nhất).', 1),
(6, 'Bất động sản 6', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Phường 2', '2 tỷ', './images/6.jpg', 'ban', '<h3>Thông tin mô tả:</h3>Mình chính chủ 02 căn góc tại căn hộ chung cư Q7 Riverside- 69m² -2.250 tỷ- 73m² - 2.3 tỷ+ Ngân hàng hỗ trợ trong vòng 20 năm với 70% giá trị căn hộ.Thông tin căn hộ Q7 Saigon Riverside:+ Vị trí: Mặt tiền đường Đào Trí, P', 1),
(8, 'Bất động sản 7', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Phường 7', '7 tỷ', './images/7.jpg', 'ban', '<h3>Thông tin mô tả:</h3>Phòng chuyển nhượng chào bán ra các căn diện thanh lý do khách hàng mất khả năng thanh toán tiền nhận nhà:(1PN - 1WC).* 53m²: Giá 1.7 tỷ.(2PN - 2WC).* 67m²: Giá 2.2 tỷ.* 69m²: Giá 2.3 tỷ.* 73m: Giá 3 tỷ.(3PN - 2WC).', 1),
(9, 'Bất động sản 8', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Phường 7', '7 tỷ', './images/8.jpg', 'ban', '<h3>Thông tin mô tả</h3>Bán nhà gia đình tại khu vực Vĩnh Hưng, Hoàng Mai, Hà Nội. Đây là một căn nhà duy nhất, độc lập, được xây dựng bởi chính gia đình chủ nhà.<br>* Với diện tích xây dựng lên đến 40.2m² và gồm 5 tầng, căn nhà này bao gồm nhiều tiện ích cho các thành viên trong gia đình.<br>+ Tầng 1 được sử dụng để để xe, bếp rộng và một phòng vệ sinh. Các tầng tiếp theo có 2 phòng ngủ khép kín ở mỗi tầng. Với hướng Tây Bắc, căn nhà này được xây dựng trong khu dân cư trí thức cao.', 1),
(10, 'Bất động sản 9', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Phường 7', '7 tỷ', './images/9.jpg', 'ban', '<h3>Thông tin mô tả</h3>Căn hộ thuộc tòa D1.Diện tích 160m².Miễn phí quản lý vận hành bởi Savill.View toàn cảnh bể bơi ngoài trờiGiá bán 8,9 tỷ.Ngoài ra, em có căn 105m² giá 5,8 tỷ.Căn 120m² giá 7,2 tỷ.Căn 200m² giá 13,3 tỷ.LH để xem căn h', 1),
(11, 'Bất động sản 10', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Phường 7', '7 tỷ', './images/10.jpg', 'ban', '<h3>Thông tin mô tả</h3>Tôi cần bán căn nhà độc lập mới xây ở khu đô thị mở rộng Vĩnh Hưng ngõ 200 số 109.- Nói không quy hoạch, quy hoạch thì mặt đường đẹp, GPXD 5 tầng nổi, căn hộ nằm xen giữa 2 biệt thự, xung quanh đều nhà liền kề, phân lô đẹp.- Hướng: Đông Nam.- Thiết kế đẹp kiểu mẫu nhà phố hiện đại -.- Diện tích xây dựng 45 m² x 5 tầng xây mới. Ngõ thông 2 đầu, ô tô để trong nhà. Có hình từ phần móng đến phần hoàn thiện cam kết hình ảnh 100 % (thiện chí quà tặng chiếc Ti vi 65 in phòng.', 2),
(13, 'Bất động sản 10123', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Phường 7', '7 tỷ', './images/11.jpg', 'ban', '<h3>Thông tin mô tả</h3>Tôi cần bán căn nhà độc lập mới xây ở khu đô thị mở rộng Vĩnh Hưng ngõ 200 số 109.- Nói không quy hoạch, quy hoạch thì mặt đường đẹp, GPXD 5 tầng nổi, căn hộ nằm xen giữa 2 biệt thự, xung quanh đều nhà liền kề, phân lô đẹp.- Hướng: Đông Nam.- Thiết kế đẹp kiểu mẫu nhà phố hiện đại -.- Diện tích xây dựng 45 m² x 5 tầng xây mới. Ngõ thông 2 đầu, ô tô để trong nhà. Có hình từ phần móng đến phần hoàn thiện cam kết hình ảnh 100 % (thiện chí quà tặng chiếc Ti vi 65 in phòng', 2),
(19, 'Bds123', 'Thành phố Hà Nội', 'Quận Ba Đình', 'Phường Phúc Xá', '1111111', './images/12.jpg', 'ban', '<h3>Thông tin mô tả</h3>Tôi cần bán căn nhà độc lập mới xây ở khu đô thị mở rộng Vĩnh Hưng ngõ 200 số 109.- Nói không quy hoạch, quy hoạch thì mặt đường đẹp, GPXD 5 tầng nổi, căn hộ nằm xen giữa 2 biệt thự, xung quanh đều nhà liền kề, phân lô đẹp.- Hướng: Đông Nam.- Thiết kế đẹp kiểu mẫu nhà phố hiện đại -.- Diện tích xây dựng 45 m² x 5 tầng xây mới. Ngõ thông 2 đầu, ô tô để trong nhà. Có hình từ phần móng đến phần hoàn thiện cam kết hình ảnh 100 % (thiện chí quà tặng chiếc Ti vi 65 in phòng', 9),
(34, 'han', 'Thành phố Hà Nội', 'Quận Ba Đình', 'Phường Trúc Bạch', '123', './images/13.jpg', 'thue', '<h3>Thông tin mô tả</h3>Tôi cần bán căn nhà độc lập mới xây ở khu đô thị mở rộng Vĩnh Hưng ngõ 200 số 109.- Nói không quy hoạch, quy hoạch thì mặt đường đẹp, GPXD 5 tầng nổi, căn hộ nằm xen giữa 2 biệt thự, xung quanh đều nhà liền kề, phân lô đẹp.- Hướng: Đông Nam.- Thiết kế đẹp kiểu mẫu nhà phố hiện đại -.- Diện tích xây dựng 45 m² x 5 tầng xây mới. Ngõ thông 2 đầu, ô tô để trong nhà. Có hình từ phần móng đến phần hoàn thiện cam kết hình ảnh 100 % (thiện chí quà tặng chiếc Ti vi 65 in phòng', 23),
(37, 'bds nha trang', 'Tỉnh Khánh Hòa', 'Thành phố Nha Trang', 'Phường Vĩnh Phước', '12 tỷ', './images/14.jpg', 'ban', '<h3>Thông tin mô tả</h3>Tôi cần bán căn nhà độc lập mới xây ở khu đô thị mở rộng Vĩnh Hưng ngõ 200 số 109.- Nói không quy hoạch, quy hoạch thì mặt đường đẹp, GPXD 5 tầng nổi, căn hộ nằm xen giữa 2 biệt thự, xung quanh đều nhà liền kề, phân lô đẹp.- Hướng: Đông Nam.- Thiết kế đẹp kiểu mẫu nhà phố hiện đại -.- Diện tích xây dựng 45 m² x 5 tầng xây mới. Ngõ thông 2 đầu, ô tô để trong nhà. Có hình từ phần móng đến phần hoàn thiện cam kết hình ảnh 100 % (thiện chí quà tặng chiếc Ti vi 65 in phòng', 26),
(38, 'bds o hn', 'Thành phố Hà Nội', 'Quận Đống Đa', 'Phường Ô Chợ Dừa', '12 tỷ', './images/15.jpg', 'thue', '4 tầng', 27),
(39, 'bds nha', 'Tỉnh Khánh Hòa', 'Thành phố Nha Trang', 'Phường Vĩnh Phước', '10 tỷ', './images/10.jpg', 'ban', 'nhà 4 tầng ', 28);

-- --------------------------------------------------------

--
-- Table structure for table `dangtin`
--

CREATE TABLE `dangtin` (
  `id_dangtin` int(50) NOT NULL,
  `title_dangtin` varchar(50) NOT NULL,
  `city_dangtin` varchar(50) NOT NULL,
  `district_dangtin` varchar(50) NOT NULL,
  `ward_dangtin` varchar(50) NOT NULL,
  `price_dangtin` varchar(50) NOT NULL,
  `image_dangtin` varchar(50) NOT NULL,
  `type_dangtin` varchar(50) NOT NULL,
  `note_dangtin` varchar(500) NOT NULL,
  `HOVATEN_dangtin` varchar(50) NOT NULL,
  `MASOTHUE_dangtin` varchar(50) NOT NULL,
  `CCCD_dangtin` varchar(50) NOT NULL,
  `SDT` varchar(50) NOT NULL,
  `dangtin_yes_no` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dangtin`
--

INSERT INTO `dangtin` (`id_dangtin`, `title_dangtin`, `city_dangtin`, `district_dangtin`, `ward_dangtin`, `price_dangtin`, `image_dangtin`, `type_dangtin`, `note_dangtin`, `HOVATEN_dangtin`, `MASOTHUE_dangtin`, `CCCD_dangtin`, `SDT`, `dangtin_yes_no`) VALUES
(1, 'Bất động sản sgf', 'Tỉnh Phú Yên', 'Thành phố Tuy Hoà', 'Phường 7', '2 tỷ', './images/2.jpg', 'ban', 'weqwew', 'ggg', '22222', '222222', '0987893678', 'no'),
(18, 'Bds123', 'Thành phố Hà Nội', 'Quận Ba Đình', 'Phường Phúc Xá', '1111111', './images/11.jpg', 'ban', '6 giupng', 'da', '111111', '1111', '0987893678', 'no'),
(21, 'han', 'Thành phố Hà Nội', 'Quận Ba Đình', 'Phường Trúc Bạch', '123', './images/9.jpg', 'thue', '123', 'sad', '123', '123', '0987893678', 'yes'),
(22, 'bds nha trang', 'Tỉnh Khánh Hòa', 'Thành phố Nha Trang', 'Phường Vĩnh Phước', '12 tỷ', './images/12.jpg', 'ban', 'chuot', 'chi', '12345', '54321', '0987893678', 'yes'),
(23, 'bds o hn', 'Thành phố Hà Nội', 'Quận Đống Đa', 'Phường Ô Chợ Dừa', '12 tỷ', './images/15.jpg', 'thue', '4 tầng', 'dat', '123456789', '9876543221', '0987893678', 'yes'),
(24, 'bds nha', 'Tỉnh Khánh Hòa', 'Thành phố Nha Trang', 'Phường Vĩnh Phước', '10 tỷ', './images/13.jpg', 'ban', 'nhà 4 tầng ', 'Ho Quoc Dat', '111111', '11111', '0987893678', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `nhadautu`
--

CREATE TABLE `nhadautu` (
  `ID_NDT` int(50) NOT NULL,
  `HOVATEN` varchar(50) DEFAULT NULL,
  `MASOTHUE` varchar(50) DEFAULT NULL,
  `CCCD` varchar(50) DEFAULT NULL,
  `SDT` varchar(50) NOT NULL,
  `id_dangtin` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nhadautu`
--

INSERT INTO `nhadautu` (`ID_NDT`, `HOVATEN`, `MASOTHUE`, `CCCD`, `SDT`, `id_dangtin`) VALUES
(1, 'Hồ Quốc Đạt', '8305639554', '054202001474', '0987893674', 1),
(2, 'Tuyn Cih', '123543123', '052204001471', '0987893676', 1),
(9, 'da', '1111112', '11112', '098789312', 18),
(23, 'sad', '123', '123', '0987893213', 21),
(26, 'chi', '12345', '54321', '0987893678', 22),
(27, 'dat', '123456789', '9876543221', '0987893678', 23),
(28, 'Ho Quoc Dat', '111111', '11111', '0987893678', 24);

-- --------------------------------------------------------

--
-- Table structure for table `phanhoi`
--

CREATE TABLE `phanhoi` (
  `id_phanhoi` int(50) NOT NULL,
  `SDT` varchar(50) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `feedback_admin` varchar(500) NOT NULL,
  `USERNAME_TK` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `phanhoi`
--

INSERT INTO `phanhoi` (`id_phanhoi`, `SDT`, `EMAIL`, `feedback`, `feedback_admin`, `USERNAME_TK`) VALUES
(8, '0987893678', 'hoquocdat@gmail.com', 'Cần update thêm nhiều tính năng mới', 'okay', 1),
(10, '0987893678', 'hoquocdat@gmail.com', 'Website rất 4.9 sao, tôi đánh giá thú vị', 'ok :3', 1),
(14, '0987893678', 'hoquocdat@gmail.com', 'Nhiều cá trong tiếng anh là gi?', 'vẫn là fish, nhiều loại cá thì mới gọi là fishes', 1),
(16, '0987893678', 'hoquocdat@gmail.com', 'ảnh bị lỗi hãy chỉnh lại giúp tôi trong bài đăng tin', 'oke :@', 1);

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `USERNAME_TK` int(50) NOT NULL,
  `PASS` varchar(50) DEFAULT NULL,
  `PASS_CONFIRM` varchar(50) DEFAULT NULL,
  `SDT` varchar(50) DEFAULT NULL,
  `EMAIL` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`USERNAME_TK`, `PASS`, `PASS_CONFIRM`, `SDT`, `EMAIL`) VALUES
(1, 'a6ee45faddb147e639bb45692e88d11382d552c7', 'a6ee45faddb147e639bb45692e88d11382d552c7', '0987893678', 'hoquocdat@gmail.com'),
(7, 'b7f1bd8f9e0636a26f8cc487af1dee6691260a15', 'b7f1bd8f9e0636a26f8cc487af1dee6691260a15', '09878936781', 'hoquocdat1@gmail.com'),
(9, '68f6c1d28ef34f255aa5c5d3158657f074f68175', '68f6c1d28ef34f255aa5c5d3158657f074f68175', '23456789', 'datdeptrai@gmail.com'),
(10, '7c4a8d09ca3762af61e59520943dc26494f8941b', '7c4a8d09ca3762af61e59520943dc26494f8941b', '123456', 'datxautrai@gmail.com'),
(15, '356a192b7913b04c54574d18c28d46e6395428ab', '356a192b7913b04c54574d18c28d46e6395428ab', '123', 'ttkh@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `thongtinkhachhang`
--

CREATE TABLE `thongtinkhachhang` (
  `ID_ttkh` int(50) NOT NULL,
  `hovaten_ttkh` varchar(50) NOT NULL,
  `gioitinh` varchar(50) NOT NULL,
  `ageborn` varchar(50) NOT NULL,
  `diachi` varchar(50) NOT NULL,
  `nghenghiep` varchar(50) NOT NULL,
  `tinhtranghonnhan` varchar(50) NOT NULL,
  `USERNAME_TK` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `thongtinkhachhang`
--

INSERT INTO `thongtinkhachhang` (`ID_ttkh`, `hovaten_ttkh`, `gioitinh`, `ageborn`, `diachi`, `nghenghiep`, `tinhtranghonnhan`, `USERNAME_TK`) VALUES
(1, 'lan', 'nam', '13/06/2003', 'hanoi', 'sinhvien', 'Độc thân', 10),
(3, 'chi', 'Nam', '2023-05-12', 'saigon', 'sinhvien', 'Độc thân', 15),
(4, 'dat', 'Nam', '2023-05-04', 'nha trang', 'hoc sinh', 'Đã kết hôn', 1),
(5, 'quynh', 'nam', '18/07/2002', 'da lat', 'hocsinh', 'Độc thân', 7),
(6, 'thao', 'nu', '08/08/2003', 'thaibinh', 'sinhvien', 'Độc thân', 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `batdongsan`
--
ALTER TABLE `batdongsan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ID_NDT` (`ID_NDT`);

--
-- Indexes for table `dangtin`
--
ALTER TABLE `dangtin`
  ADD PRIMARY KEY (`id_dangtin`);

--
-- Indexes for table `nhadautu`
--
ALTER TABLE `nhadautu`
  ADD PRIMARY KEY (`ID_NDT`),
  ADD KEY `id_dangtin` (`id_dangtin`);

--
-- Indexes for table `phanhoi`
--
ALTER TABLE `phanhoi`
  ADD PRIMARY KEY (`id_phanhoi`),
  ADD KEY `USERNAME_TK` (`USERNAME_TK`);

--
-- Indexes for table `taikhoan`
--
ALTER TABLE `taikhoan`
  ADD PRIMARY KEY (`USERNAME_TK`);

--
-- Indexes for table `thongtinkhachhang`
--
ALTER TABLE `thongtinkhachhang`
  ADD PRIMARY KEY (`ID_ttkh`),
  ADD KEY `USERNAME_TK` (`USERNAME_TK`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `batdongsan`
--
ALTER TABLE `batdongsan`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `dangtin`
--
ALTER TABLE `dangtin`
  MODIFY `id_dangtin` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `nhadautu`
--
ALTER TABLE `nhadautu`
  MODIFY `ID_NDT` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `phanhoi`
--
ALTER TABLE `phanhoi`
  MODIFY `id_phanhoi` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `taikhoan`
--
ALTER TABLE `taikhoan`
  MODIFY `USERNAME_TK` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `thongtinkhachhang`
--
ALTER TABLE `thongtinkhachhang`
  MODIFY `ID_ttkh` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `batdongsan`
--
ALTER TABLE `batdongsan`
  ADD CONSTRAINT `batdongsan_ibfk_1` FOREIGN KEY (`ID_NDT`) REFERENCES `nhadautu` (`ID_NDT`);

--
-- Constraints for table `nhadautu`
--
ALTER TABLE `nhadautu`
  ADD CONSTRAINT `nhadautu_ibfk_1` FOREIGN KEY (`id_dangtin`) REFERENCES `dangtin` (`id_dangtin`);

--
-- Constraints for table `phanhoi`
--
ALTER TABLE `phanhoi`
  ADD CONSTRAINT `phanhoi_ibfk_1` FOREIGN KEY (`USERNAME_TK`) REFERENCES `taikhoan` (`USERNAME_TK`);

--
-- Constraints for table `thongtinkhachhang`
--
ALTER TABLE `thongtinkhachhang`
  ADD CONSTRAINT `thongtinkhachhang_ibfk_1` FOREIGN KEY (`USERNAME_TK`) REFERENCES `taikhoan` (`USERNAME_TK`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
